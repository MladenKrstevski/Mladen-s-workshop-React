import axios from "../custom-axios/axios";

const EShopService = {
    fetchManufacturers: () => {
        return axios.get("/manufacturers");
    },
    fetchCategories: () => {
        return axios.get("/categories");
    },
    fetchProducts: () => {
        return axios.get("/products");
    },
    deleteProduct: (id) => {
        return axios.delete(`/products/delete/${id}`);
    },
    deleteCategory: (id) => {
        return axios.delete(`/categories/delete/${id}`);
    },
    deleteManufacturer: (id) => {
        return axios.delete(`/manufacturers/delete/${id}`);
    },
    addProduct: (name, price, quantity, category, manufacturer, imageUrl) => {
        return axios.post("/products/add", {
            "name": name,
            "price": price,
            "quantity": quantity,
            "category": category,
            "manufacturer": manufacturer,
            "imageUrl": imageUrl
        })
    },
    editProduct: (id, name, price, quantity, category, manufacturer, imageUrl) => {
        return axios.put(`/products/edit/${id}`, {
            "name": name,
            "price": price,
            "quantity": quantity,
            "category": category,
            "manufacturer": manufacturer,
            "imageUrl": imageUrl
        });
    },
    getProduct: (id) => {
        return axios.get(`/products/${id}`);
    },
    login: (username, password) => {
        return axios.post("/login", {
            "username": username,
            "password": password
        });
    }
}

export default EShopService;