import React from 'react';
import {Link} from 'react-router-dom';

const header = (props) => {

    let authenticate
    if (localStorage.getItem("JWT")) {
        authenticate = (<button className="btn btn-outline-info my-2 my-sm-0 position-absolute bottom-0 end-0 m-4"
                                onClick={() => localStorage.removeItem("JWT")}>Logout</button>);
    } else {
        authenticate = (<Link className="btn btn-outline-info my-2 my-sm-0 position-absolute bottom-0 end-0 m-4" to={"/login"}>Login</Link>);
    }
    return (
        <header>
            <nav className="navbar navbar-expand-md navbar-dark navbar-fixed">
                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse"
                        aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarCollapse">
                    
                    <form className="form-inline mt-2 mt-md-0 ml-3">
                        {authenticate}
                    </form>
                </div>
            </nav>
        </header>
    )
}

export default header;