import React from "react";

const manufacturers = (props) => {
    return (
        <div className="container mm-4">
            <div className = {"row"}>
                <div className = {"row"}>
                    <table className="table table-stripped">
                        <thead>
                            <tr>
                                <th className="text-black" scope={"col"}>Name</th>
                                <th className=" text-black" scope={"col"}>Address</th>
                            </tr>
                        </thead>
                        <tbody>
                            {props.manufacturers.map((term) => {
                                return (
                                    <tr>
                                        <td className=" text-black">
                                            {term.name}
                                        </td>
                                        <td className=" text-black">
                                            {term.address}
                                        </td>
                                        <td scope = {"col"} className = {"text-right "}>
                <a title={"Delete"} className={"btn btn-danger"} 
                    onClick={() => props.onDelete(term.id)}>Delete
                </a>
            </td>
                                    </tr>
                                )
                            })};
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}

export default manufacturers;