import React from "react";
import { Link } from "react-router-dom";

const productTerm = (props) => {
    return (
        <tr>
            <td className="" scope = {"col"}>
                <img src={props.productTerm.imageUrl} width="150" height="150"/> 
            </td>
            <td className=" text-black" scope = {"col"}>{props.productTerm.name}</td>
            <td className=" text-black" scope = {"col"}>{props.productTerm.price}</td>
            <td className=" text-black" scope = {"col"}>{props.productTerm.quantity}</td>
            <td className="text-black text-black" scope = {"col"}>{props.productTerm.category.name}</td>
            <td className=" text-black" scope = {"col"}>{props.productTerm.manufacturer.name}</td>
            <td scope = {"col"} className = {"text-right "}>
                <a title={"Delete"} className={"btn btn-outline-danger  text-danger m-2"} 
                    onClick={() => props.onDelete(props.productTerm.id)}>Delete
                </a>
                <Link className={"btn btn-info ml-2"}
                    onClick={() => props.onEdit(props.productTerm.id)}
                    to={`/products/edit/${props.productTerm.id}`}>Edit
                </Link>
            </td>
        </tr>
    )
}

export default productTerm;