import React from "react";
import ReactPaginate from "react-paginate";
import ProductTerm from "../ProductTerm/productTerm";
import { Link } from "react-router-dom";
import "./products.css";

class Products extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            page: 0,
            size: 2,
            filterByName: "",
            filterByCategory: "",
            filterByManufacturer: ""
        }
    }

    render() {

        const offset = this.state.size * this.state.page;
        const nextPageOffset = offset + this.state.size;
        const pageCount = Math.ceil(this.props.products.length / this.state.size);
        const products = this.getProductsPage(offset, nextPageOffset);

        return (
            <div className={"container mm-2 "}>
                <div className="col-mb-3 text-center">
                    <div className="row py-4">
                        <div className="col-sm-12 col-md-12">
                            <Link className={"btn btn-block btn-secondary btn-lg col-sm-3"} to={"/products/add"}>Add new product</Link>
                        </div>
                    </div>
                </div>
                <div className={"row"}>
                    <div className="filter-container col-md-4 ">
                        <div className="text-black">Search by name:</div>
                        <div className="form-group">
                            <input type="search" id="searchbar" className="form-control" onChange={this.nameSelect}/>
                            <label className="text-black form-label" for="searchbar"></label>
                        </div>
                    </div>
                    <div className="filter-container col-md-4">
                        <div className="text-black">Filter by Category:</div>
                        <div className="form-group">

                            <select name="category" className="form-control" onChange={this.categorySelect}>
                                <option value="" selected>None</option>
                                {this.props.categories.map((term) =>
                                    <option value={term.id}>{term.name}</option>
                                )}
                            </select>
                        </div>
                    </div>
                    <div className="filter-container col-md-4">
                        <div className="text-black">Filter by Manufacturer:</div>
                        <div className="form-group">

                            <select name="manufacturer" className="form-control" onChange={this.manufacturerSelect}>
                                <option value="" selected>None</option>
                                {this.props.manufacturers.map((term) =>
                                    <option value={term.id}>{term.name}</option>
                                )}
                            </select>
                        </div>
                    </div>
                    <div className={"table-responsive"}>
                        <table className={"table table-stripped"}>
                            <thead>
                                <tr>
                                    <th className=" text-black" scope={"col"}>Image</th>
                                    <th className=" text-black" scope={"col"}>Name</th>
                                    <th className=" text-black" scope={"col"}>Price</th>
                                    <th className=" text-black" scope={"col"}>Quantity</th>
                                    <th className=" text-black" scope={"col"}>Category</th>
                                    <th className=" text-black" scope={"col"}>Manufacturer</th>
                                </tr>
                            </thead>
                            <tbody>
                                {products}
                            </tbody>
                        </table>
                    </div>
                </div>



                <ReactPaginate previousLabel={"back"}
                    nextLabel={"next"}
                    breakLabel={<a href="/#">...</a>}
                    breakClassName={"break-me"}
                    pageClassName={"ml-1"}
                    pageCount={pageCount}
                    marginPagesDisplayed={2}
                    pageRangeDisplayed={5}
                    onPageChange={this.handlePageClick}
                    containerClassName={"pagination m-4 justify-content-center text-black"}
                    activeClassName={"active"} />

            </div>

        )
    }

    handlePageClick = (data) => {
        let selected = data.selected;
        this.setState({
            page: selected
        })
    }

    getProductsPage = (offset, nextPageOffset) => {
        return this.props.products

            .filter((item) => (this.state.filterByName !== ""
                && item.name.toLowerCase().includes(this.state.filterByName.toLowerCase()))
                || this.state.filterByName == "")

            .filter((item) => (this.state.filterByManufacturer != ""
                && item.manufacturer.id == this.state.filterByManufacturer)
                || this.state.filterByManufacturer == "")

            .filter((item) => (this.state.filterByCategory != ""
                && item.category.id == this.state.filterByCategory)
                || this.state.filterByCategory == "")
            .map((product) => {
                return (
                    <ProductTerm productTerm={product} onDelete={this.props.onDelete} onEdit={this.props.onEdit} />
                );
            })
            .filter((product, index) => {
                return index >= offset && index < nextPageOffset;
            })
    }

    nameSelect = (event) => {
        this.setState({
            filterByName: event.target.value
        })
    }

    categorySelect = (event) => {
        console.log(event.target.value)
        this.setState({
            filterByCategory: event.target.value
        })
    }

    manufacturerSelect = (event) => {
        console.log(event.target.value)
        this.setState({
            filterByManufacturer: event.target.value
        })
    }
}

export default Products;