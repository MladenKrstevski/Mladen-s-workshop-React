import React from "react";

const categories = (props) => {
    return (
        <div className="container mm-4">
            <div className = {"row"}>
                <div className = {"row"}>
                    <table className="table table-stripped">
                        <thead>
                            <tr>
                                <th className=" text-black" scope={"col"}>Name</th>
                                <th className=" text-black" scope={"col"}>Description</th>
                            </tr>
                        </thead>
                        <tbody>
                            {props.categories.map((category) => {
                                return (
                                    <tr>
                                        <td className=" text-black">
                                            {category.name}
                                        </td>
                                        <td className=" text-black">
                                            {category.description}
                                        </td>
                                       <td scope = {"col"} className = {"text-right "}>
                <a title={"Delete"} className={"btn btn-danger"} 
                    onClick={() => props.onDelete(category.id)}>Delete
                </a>
            </td> 
                                    </tr>
                                )
                            })};
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    )
}

export default categories;