import './App.css';
import React, { Component } from "react";
import Manufacturers from '../Manufacturers/manufacturers';
import EShopService from '../../repository/eShopRepository';
import { BrowserRouter as Router, Redirect, Route, Routes, Navigate} from 'react-router-dom';
import Categories from '../Categories/categories';
import Products from '../Products/ProductList/products';
import Header from '../Header/header';
import ProductAdd from '../Products/ProductAdd/productAdd';
import ProductEdit from '../Products/ProductEdit/productEdit';
import Login from "../Login/login";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      manufacturers: [],
      categories: [],
      products: [],
      selectedProduct: {}
    }
  }

  render() {
    return (
      <Router>
        <Header/>
        <main className="">
          <div className="container">
            <Routes>
              <Route path={"/manufacturers"} element = {<Manufacturers manufacturers = {this.state.manufacturers} onDelete = {this.deleteManufacturer}/>}/>
              <Route path={"/categories"} element ={ <Categories categories = {this.state.categories} onDelete = {this.deleteCategory}/>}/>
              <Route path={"/products/add"} element ={ <ProductAdd categories = {this.state.categories} manufacturers = {this.state.manufacturers} onAddProduct={this.addProduct}/>}/>
              <Route path={"/products/edit/:id"} element ={ <ProductEdit categories = {this.state.categories} 
                manufacturers = {this.state.manufacturers}
                onEditProduct={this.editProduct} 
                product = {this.state.selectedProduct}/>}/>
              <Route path={"/products"} element ={ <Products products = {this.state.products} categories = {this.state.categories} manufacturers = {this.state.manufacturers}
                onDelete = {this.deleteProduct}
                onEdit = {this.getProduct}
                />}/>
                <Route path={"/login"} element={<Login onLogin={this.fetchData}/>}/>
              <Route path={"*"} element = { <Navigate to = "/products"/>}/>
            </Routes>
            
          </div>
        </main>
      </Router>
    )
  }

  fetchData = () => {
    this.loadManufacturers();
    this.loadCategories();
    this.loadProducts();
}

loadManufacturers =()=> {
  EShopService.fetchManufacturers()
  .then((data) => {
    this.setState({
      manufacturers:  data.data
    })
  });
}

loadCategories =()=> {
  EShopService.fetchCategories()
  .then((data) => {
    this.setState({
      categories:  data.data
    })
  });
}

loadProducts =()=> {
  EShopService.fetchProducts()
  .then((data) => {
    this.setState({
      products:  data.data
    })
  });
}

deleteProduct = (id) => {
  EShopService.deleteProduct(id)
  .then(() => {
    this.loadProducts();
  })
}

deleteManufacturer = (id) => {
  EShopService.deleteManufacturer(id)
  .then(() => {
    this.loadManufacturers();
  })
}

deleteCategory = (id) => {
  EShopService.deleteCategory(id)
  .then(() => {
    this.loadCategories();
  })
}

addProduct = (name, price, quantity, category, manufacturer, imageUrl) => {
  EShopService.addProduct(name, price, quantity, category, manufacturer, imageUrl)
  .then(() => {
    this.loadProducts();
  })
}

getProduct = (id) => {
  EShopService.getProduct(id)
  .then((data) => {
    this.setState( {
      selectedProduct: data.data
    })
  })
}

editProduct = (id, name, price, quantity, category, manufacturer, imageUrl) => {
  EShopService.editProduct(id, name, price, quantity, category, manufacturer, imageUrl)
  .then(() => this.loadProducts())
}

  componentDidMount() {
  this.fetchData();
}
}

export default App;